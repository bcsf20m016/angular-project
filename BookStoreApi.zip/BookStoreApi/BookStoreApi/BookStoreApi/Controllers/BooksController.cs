﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Web_API.BusinessLayer;
using Web_API.Models;

namespace Web_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class BooksController : ControllerBase
    {
        private readonly BookBL bookBL;
        public BooksController(BookBL bookBL)
        {
            this.bookBL = bookBL;
        }

        [HttpGet]
        public ActionResult<List<Book>> getAllBooks()
        {
            return Ok(bookBL.GetBooks());
        }

        [HttpGet("{id}")]
        public ActionResult<Book> getBookById(int id)
        {
            var book = bookBL.GetBookById(id);
            if(book is not null)
            {
                return Ok(book);
            }
            return NotFound(new { Message = "Book not found" });
        }

        [HttpGet("author/{author}")]
        public ActionResult<List<Book>> getBooksByAuthor(string author)
        {
            return Ok(bookBL.GetBooksByAuthor(author));
        }

        [HttpPost]
        public ActionResult<Book> addBook(Book book)
        {
            var result = bookBL.AddBook(book);
            return Ok(result);
        }

        [HttpPut("{id}")]
        public ActionResult updateBookById(int id, Book book)
        {
            var isUpdated = bookBL.UpdateBook(id, book);
            if(isUpdated)
            {
                return Ok(new { Message = "Book updated successfully" });
            }
            return NotFound(new { Message = "Book not found" });
        }

        [HttpDelete("{id}")]
        public ActionResult removeBookById(int id)
        {
            var isDeleted = bookBL.RemoveBookById(id);
            if(isDeleted)
            {
                return Ok(new { Message = "Book deleted successfully" });
            }
            return NotFound(new { Message = "Book not found" });
        }
    }
}

