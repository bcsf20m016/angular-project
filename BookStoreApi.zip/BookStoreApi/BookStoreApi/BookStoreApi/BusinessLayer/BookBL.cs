﻿using System;
using Web_API.DataAccessLayer;
using Web_API.Models;

namespace Web_API.BusinessLayer
{
	public class BookBL
	{
		private readonly BookDAL bookDAL;
        public BookBL(BookDAL bookDAL)
        {
            this.bookDAL = bookDAL;
        }

        public List<Book> GetBooks()
        {
            return bookDAL.GetBooks();
        }

        public Book? GetBookById(int id)
        {
            return bookDAL.GetBookById(id);
        }

        public List<Book> GetBooksByAuthor(string author)
        {
            return bookDAL.GetBooksByAuthor(author);
        }

        public Book AddBook(Book book)
        {
            return bookDAL.AddBook(book);
        }

        public bool UpdateBook(int id, Book book)
        {
            var existingBook = bookDAL.GetBookById(id);
            if (existingBook is not null)
            {
                book.Id = id;
                bookDAL.UpdateBook(book);
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool RemoveBookById(int id)
        {
            return bookDAL.RemoveBookById(id);
        }
    }
}

