﻿using System;
using Web_API.Models;
using System.Data;
using System.Data.SqlClient;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Web_API.DataAccessLayer
{
	public class BookDAL
	{
        private readonly string _connectionString;
        
        public BookDAL(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public List<Book> GetBooks()
        {
            var books = new List<Book>();
            using(var con = new SqlConnection(_connectionString))
            {
                var command = new SqlCommand("GetAllBooks", con) 
                { 
                    CommandType = CommandType.StoredProcedure
                };
                con.Open();
                using (var data = command.ExecuteReader())
                {
                    while (data.Read())
                    {
                        Book book = new Book
                        {
                            Id = (int)data["Id"],
                            Title = (string)data["Title"],
                            Author = (string)data["Author"],
                            Description = (string)data["Description"],
                            ImageUrl = (string)data["ImageUrl"]
                        };
                        books.Add(book);
                    }
                }
            }
            return books;
        }

        public Book? GetBookById(int id)
        {
            Book book = null;
            using (var con = new SqlConnection(_connectionString))
            {
                var command = new SqlCommand("GetBookById", con)
                {
                    CommandType = CommandType.StoredProcedure
                };
                command.Parameters.AddWithValue("@bookId", id);
                con.Open();
                using(var data = command.ExecuteReader())
                {
                    if(data.Read())
                    {
                        book = new Book
                        {
                            Id = (int)data["Id"],
                            Title = (string)data["Title"],
                            Author = (string)data["Author"],
                            Description = (string)data["Description"],
                            ImageUrl = (string)data["ImageUrl"]
                        };
                    }
                }
            }
            return book;
        }

        public List<Book> GetBooksByAuthor(string author)
        {
            var books = new List<Book>();
            using (var con = new SqlConnection(_connectionString))
            {
                var command = new SqlCommand("GetBookByAuthor", con)
                {
                    CommandType = CommandType.StoredProcedure
                };
                command.Parameters.AddWithValue("@author", author);
                con.Open();
                using (var data = command.ExecuteReader())
                {
                    while (data.Read())
                    {
                        Book book = new Book
                        {
                            Id = (int)data["Id"],
                            Title = (string)data["Title"],
                            Author = (string)data["Author"],
                            Description = (string)data["Description"],
                            ImageUrl = (string)data["ImageUrl"]
                        };
                        books.Add(book);
                    }
                }
            }
            return books;
        }

        public Book AddBook(Book book)
        {
            Book newBook = null;
            using (var con = new SqlConnection(_connectionString))
            {
                var command = new SqlCommand("AddBook", con)
                {
                    CommandType = CommandType.StoredProcedure
                };
                command.Parameters.AddWithValue("@title", book.Title);
                command.Parameters.AddWithValue("@author", book.Author);
                command.Parameters.AddWithValue("@description", book.Description);
                command.Parameters.AddWithValue("@imageUrl", book.ImageUrl);
                con.Open();
                command.ExecuteNonQuery();

                int id = 0;
                command = new SqlCommand("GetLastBookId", con)
                {
                    CommandType = CommandType.StoredProcedure
                };
                var result = command.ExecuteScalar();
                id = Convert.ToInt32(result);
                newBook = GetBookById(id);
            }
            return newBook;
        }

        public bool UpdateBook(Book updatedBook)
        {
            int result = 0;
            using (var con = new SqlConnection(_connectionString))
            {
                var command = new SqlCommand("UpdateBook", con)
                {
                    CommandType = CommandType.StoredProcedure
                };
                command.Parameters.AddWithValue("@id", updatedBook.Id);
                command.Parameters.AddWithValue("@title", updatedBook.Title);
                command.Parameters.AddWithValue("@author", updatedBook.Author);
                command.Parameters.AddWithValue("@description", updatedBook.Description);
                command.Parameters.AddWithValue("@imageUrl", updatedBook.ImageUrl);
                con.Open();
                result = command.ExecuteNonQuery();
            }
            if (result > 0)
                return true;
            return false;
        }

        public bool RemoveBookById(int id)
        {
            int result = 0;
            using (var con = new SqlConnection(_connectionString))
            {
                var command = new SqlCommand("DeleteBook", con)
                {
                    CommandType = CommandType.StoredProcedure
                };
                command.Parameters.AddWithValue("@id", id);
                con.Open();
                result = command.ExecuteNonQuery();
            }
            if (result > 0)
                return true;
            return false;
        }

    }
}

